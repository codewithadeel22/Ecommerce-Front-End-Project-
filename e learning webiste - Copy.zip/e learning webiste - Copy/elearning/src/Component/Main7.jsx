import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import Testimonial1 from "../assets/testimonial-1.jpg";
import Testimonial2 from "../assets/testimonial-2.jpg";
import Testimonial3 from "../assets/testimonial-3.jpg";
import Testimonial4 from "../assets/testimonial-4.jpg";

function Main7() {

  return (
    <div className="box">
      <div className="container-xxl py-5 category">
        <div className="container">
          <div className="text-center wow fadeInUp" data-wow-delay="0.1s" style={{ visibility: 'visible', animationDelay: '0.1s', animationName: 'fadeInUp' }}>
            <h6 className="section-title bg-white text-center text-primary px-3 with-lines">
              <h6 className="section-title bg-white text-center text-primary px-3 with-line"></h6>
              Testimonial
            </h6>
            <h1 className="mb-5">Our Students Say!</h1>
          </div>
        </div>
        <Carousel
          useKeyboardArrows={false}
          showArrows={false}  
          renderIndicator={(onClickHandler, isSelected, index, label) => {
            const customDotStyle = {
              width: '1rem',
              height: '1rem',
              margin: '0 5px',
              backgroundColor: isSelected ? '#728cd4' : 'white',
              border: '1px solid #9c9c9c',
              display: 'inline-block',
              cursor: 'pointer',
              position: 'relative',
              top: '1rem',
            };

            return (
              <li
                className={`${isSelected ? 'selected' : ''}`}
                onClick={onClickHandler}
                onKeyDown={onClickHandler}
                value={index}
                key={index}
                role="button"
                tabIndex={0}
                style={customDotStyle}
              />
            );
          }}
        >
        
        <div className="service-item text-center pt-3" style={{ display: 'flex', flexDirection: 'row', padding: '0 1rem', gap: '1rem' }}>

      <div className="testimonial-item text-center">
        <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial1} style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
        <h5 className="mb-0">Client Name 1</h5>
        <p>Profession</p>
        <div className="testimonial-text bg-light text-center p-4">
          <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
        </div>
      </div>
      <div className="testimonial-item text-center">
      <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial2}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
      <h5 className="mb-0">Client Name 1</h5>
      <p>Profession</p>
      <div className="testimonial-text bg-light text-center p-4">
        <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
      </div>
    </div>
    <div className="testimonial-item text-center">
    <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial3}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
    <h5 className="mb-0">Client Name 1</h5>
    <p>Profession</p>
    <div className="testimonial-text bg-light text-center p-4">
      <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
    </div>
  </div>
  <div className="testimonial-item text-center">
  <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial4}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
  <h5 className="mb-0">Client Name 1</h5>
  <p>Profession</p>
  <div className="testimonial-text bg-light text-center p-4">
    <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
  </div>
</div></div>
<div className="service-item text-center pt-3" style={{ display: 'flex', flexDirection: 'row', padding: '0 7rem', gap: '1rem' }}>
      <div className="testimonial-item text-center">
        <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial1} style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
        <h5 className="mb-0">Client Name 1</h5>
        <p>Profession</p>
        <div className="testimonial-text bg-light text-center p-4">
          <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
        </div>
      </div>
      <div className="testimonial-item text-center">
      <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial2}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
      <h5 className="mb-0">Client Name 1</h5>
      <p>Profession</p>
      <div className="testimonial-text bg-light text-center p-4">
        <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
      </div>
    </div>
    <div className="testimonial-item text-center">
    <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial3}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
    <h5 className="mb-0">Client Name 1</h5>
    <p>Profession</p>
    <div className="testimonial-text bg-light text-center p-4">
      <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
    </div>
  </div>
  <div className="testimonial-item text-center">
  <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial4}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
  <h5 className="mb-0">Client Name 1</h5>
  <p>Profession</p>
  <div className="testimonial-text bg-light text-center p-4">
    <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
  </div>
</div></div>
<div className="service-item text-center pt-3" style={{ display: 'flex', flexDirection: 'row', padding: '0 7rem', gap: '1rem' }}>
      <div className="testimonial-item text-center">
        <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial1} style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
        <h5 className="mb-0">Client Name 1</h5>
        <p>Profession</p>
        <div className="testimonial-text bg-light text-center p-4">
          <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
        </div>
      </div>
      <div className="testimonial-item text-center">
      <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial2}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
      <h5 className="mb-0">Client Name 1</h5>
      <p>Profession</p>
      <div className="testimonial-text bg-light text-center p-4">
        <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
      </div>
    </div>
    <div className="testimonial-item text-center">
    <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial3}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
    <h5 className="mb-0">Client Name 1</h5>
    <p>Profession</p>
    <div className="testimonial-text bg-light text-center p-4">
      <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
    </div>
  </div>
  <div className="testimonial-item text-center">
  <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial4}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
  <h5 className="mb-0">Client Name 1</h5>
  <p>Profession</p>
  <div className="testimonial-text bg-light text-center p-4">
    <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
  </div>
</div></div>
<div className="service-item text-center pt-3" style={{ display: 'flex', flexDirection: 'row', padding: '0 7rem', gap: '1rem' }}>
      <div className="testimonial-item text-center">
        <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial1} style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
        <h5 className="mb-0">Client Name 1</h5>
        <p>Profession</p>
        <div className="testimonial-text bg-light text-center p-4">
          <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
        </div>
      </div>
      <div className="testimonial-item text-center">
      <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial2}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
      <h5 className="mb-0">Client Name 1</h5>
      <p>Profession</p>
      <div className="testimonial-text bg-light text-center p-4">
        <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
      </div>
    </div>
    <div className="testimonial-item text-center">
    <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial3}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
    <h5 className="mb-0">Client Name 1</h5>
    <p>Profession</p>
    <div className="testimonial-text bg-light text-center p-4">
      <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
    </div>
  </div>
  <div className="testimonial-item text-center">
  <img className="border rounded-circle p-2 mx-auto mb-3" src={Testimonial4}  style={{ width: '80px', height: '80px' }} alt="Client Avatar 1" />
  <h5 className="mb-0">Client Name 1</h5>
  <p>Profession</p>
  <div className="testimonial-text bg-light text-center p-4">
    <p className="mb-0">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
  </div>
</div></div>
      </Carousel>
    </div></div>
  );
}
export default Main7;