import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faGraduationCap, faGlobe, faHome, faBookOpen } from '@fortawesome/free-solid-svg-icons';

function Main2() {
  return (
    <div className="service-item text-center pt-3 d-flex flex-wrap justify-content-center">
      <div className="p-4 bg-info bg-gradient mb-4 mx-2" style={{ maxWidth: '300px' }}>
        <FontAwesomeIcon icon={faGraduationCap} size="3x" color="primary" />
        <h5 className="mb-3">Skilled Instructors</h5>
        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam</p>
      </div>
      <div className="p-4 bg-info bg-gradient mb-4 mx-2" style={{ maxWidth: '300px' }}>
        <FontAwesomeIcon icon={faGlobe} size="3x" color="primary" />
        <h5 className="mb-3">Online Classes</h5>
        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam</p>
      </div>
      <div className="p-4 bg-info bg-gradient mb-4 mx-2" style={{ maxWidth: '300px' }}>
        <FontAwesomeIcon icon={faHome} size="3x" color="primary" />
        <h5 className="mb-3">Home Projects</h5>
        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam</p>
      </div>
      <div className="p-4 bg-info bg-gradient mb-4 mx-2" style={{ maxWidth: '300px' }}>
        <FontAwesomeIcon icon={faBookOpen} size="3x" color="primary" />
        <h5 className="mb-3">Book Library</h5>
        <p>Diam elitr kasd sed at elitr sed ipsum justo dolor sed clita amet diam</p>
      </div>
    </div>
  );
}

export default Main2;
