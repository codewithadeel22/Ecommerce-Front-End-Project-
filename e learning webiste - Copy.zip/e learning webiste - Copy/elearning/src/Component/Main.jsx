import React, { Component } from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import bgpic from "../assets/pic1.jpg";
import bgpic2 from "../assets/pic2.jpg";
import arrowleft from "../assets/leftarrow.png";
import arrowright from "../assets/rightarrow.png";

export default class Main extends Component {
  constructor(props) {
    super(props);
    this.next = this.next.bind(this);
    this.previous = this.previous.bind(this);
  }

  next() {
    this.slider.slickNext();
  }

  previous() {
    this.slider.slickPrev();
  }

  render() {
    const settings = {
      dots: false,
      infinite: false,
      speed: 500,
      slidesToShow: 1,
      slidesToScroll: 1
    };

    return (
      <div>
        <Slider ref={(c) => (this.slider = c)} {...settings} >
          <div className="carousel-item">
            <img src={bgpic} alt="Slide 1" style={{width:'93rem'}}/>
          </div>
          <div className="carousel-item">
            <img src={bgpic2} alt="Slide 1" style={{width:'93rem'}}/>
          </div>
        </Slider>

        <div className="carousel-content">
        <div className="container text-left mt-5">
        <h4 className="text-primary fw-bold">BEST ONLINE COURSES</h4>
        <h1 className="display-4 fw-bold">Get Educated Online</h1>
        <h1 className="display-4 fw-bold">From Your Home</h1>
        <p className="lead fw-bold">
          Lorem ipsum is placeholder text commonly used in the graphic, print,
          <br /> and publishing industries for previewing layouts and visual mockups.
        </p>
      </div>

          <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
            <button className="btn btn-primary btn-sm">Read More</button>
            <button class="btn btn-primary" style={{background:'white',color:'black'}}>Join Now</button>
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end', position: 'relative', bottom: '30rem', right: '1rem' }}>
       <button className="button1" onClick={this.previous} style={{ background: `url(${arrowleft}) no-repeat`, backgroundSize: 'cover', width: '40px', height: '40px', border: '1px solid white', marginRight: '10px' }}></button>
       <button className="button" onClick={this.next} style={{ background: `url(${arrowright}) no-repeat`, backgroundSize: 'cover', width: '40px', height: '40px', border: '1px solid white' }}></button>
</div>

      </div>
    );
  }
}
