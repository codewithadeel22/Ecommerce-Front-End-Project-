import React from 'react';
import About from "../assets/about.jpg";
import Line from "../assets/line.png";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowRight } from '@fortawesome/free-solid-svg-icons';

function Main3() {
  return (
    <div>
      <div className="container-xxl py-5">
        <div className="container">
          <div className="row g-5">
            <div className="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style={{ minHeight: '400px', visibility: 'visible', animationDelay: '0.1s', animationName: 'fadeInUp' }}>
              <div className="position-relative h-100">
                <img className="img-fluid position-absolute w-100 h-100" src={About} alt="" style={{ objectFit: 'cover' }} />
              </div>
            </div>
            <div className="col-lg-6 wow fadeInUp" data-wow-delay="0.3s" style={{ visibility: 'visible', animationDelay: '0.3s', animationName: 'fadeInUp' }}>
              <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
              <h6 className="section-title bg-white text-center text-primary px-3 with-lines-about">About Us</h6>
              <h6 className="section-title bg-white text-center text-primary px-3 with-line-about"></h6>
              </div>

              <h1 className="mb-4">Welcome to eLEARNING</h1>
              <p className="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit.</p>
              <p className="mb-4">Tempor erat elitr rebum at clita. Diam dolor diam ipsum sit. Aliqu diam amet diam et eos. Clita erat ipsum et lorem et sit, sed stet lorem sit clita duo justo magna dolore erat amet</p>
              <div className="row gy-2 gx-4 mb-4">
                <div className="col-sm-6">
                  <p className="mb-0"><FontAwesomeIcon icon={faArrowRight} className="text-primary me-2" />Skilled Instructors</p>
                </div>
                <div className="col-sm-6">
                  <p className="mb-0"><FontAwesomeIcon icon={faArrowRight} className="text-primary me-2" />Online Classes</p>
                </div>
                <div className="col-sm-6">
                  <p className="mb-0"><FontAwesomeIcon icon={faArrowRight} className="text-primary me-2" />International Certificate</p>
                </div>
                <div className="col-sm-6">
                  <p className="mb-0"><FontAwesomeIcon icon={faArrowRight} className="text-primary me-2" />Skilled Instructors</p>
                </div>
                <div className="col-sm-6">
                  <p className="mb-0"><FontAwesomeIcon icon={faArrowRight} className="text-primary me-2" />Online Classes</p>
                </div>
                <div className="col-sm-6">
                  <p className="mb-0"><FontAwesomeIcon icon={faArrowRight} className="text-primary me-2" />International Certificate</p>
                </div>
              </div>
              <a className="btn btn-primary py-3 px-5 mt-2" href="">Read More</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Main3;
