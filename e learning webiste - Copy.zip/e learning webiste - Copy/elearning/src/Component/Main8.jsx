import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt, faPhoneAlt, faEnvelope } from '@fortawesome/free-solid-svg-icons';
import Course1 from "../assets/course-1.jpg";
import Course2 from "../assets/course-2.jpg";
import Course3 from "../assets/course-3.jpg";

function Main8() {
  return (
    <div>
    
      <div className="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s" style={{ visibility: 'visible', animationDelay: '0.1s', animationName: 'fadeIn' }}>
        <div className="container py-5">
          <div className="row g-5">
          <div class="col-lg-3 col-md-6 quick-links-container">
          <h4 class="text-white mb-3">Quick Link</h4>
          <a class="btn btn-link" href="#">
            <span class="arrow-icon">➤</span> About Us
          </a>
          <a class="btn btn-link" href="#">
            <span class="arrow-icon">➤</span> Contact Us
          </a>
          <a class="btn btn-link" href="#">
            <span class="arrow-icon">➤</span> Privacy Policy
          </a>
          <a class="btn btn-link" href="#">
            <span class="arrow-icon">➤</span> Terms &amp; Condition
          </a>
          <a class="btn btn-link" href="#">
            <span class="arrow-icon">➤</span> FAQs &amp; Help
          </a>
        </div>
        <div className="col-lg-3 col-md-6">
        <h4 className="text-white mb-3">Contact</h4>
        <p className="mb-2">
          <FontAwesomeIcon icon={faMapMarkerAlt} className="me-3" />
          123 Street, New York, USA
        </p>
        <p className="mb-2">
          <FontAwesomeIcon icon={faPhoneAlt} className="me-3" />
          +012 345 67890
        </p>
        <p className="mb-2">
          <FontAwesomeIcon icon={faEnvelope} className="me-3" />
          info@example.com
        </p>
        <div className="d-flex pt-2">
        <a className="btn btn-outline-light btn-social" href="#" style={{ border: '1px solid #222A31' }}>
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAHbUlEQVR4nN1a+VMUVxDmb1lDDhWPBUUEFS80igbxoiivJGDE+45IFERExVvE20gSNSYxUQMeoAgo3qICIhpB8UIFUSKsWiDVqe/tvucucy8jWPmhq7Z2evq9b14fX/eMh6VtZ/o/iEdrb+CjA2L1C6SJU2fRtl2pdCrnNN0pLaMXL1/S27dvmeD3P6Vl7Bp0IqfMpM7den0cQL7o7Euzv4+h03nnqKGhgRobGw1JfX0D5eadpVnzF9LnnXxbHkhbazdatnINPXn6TGzqzZs3dO7CRVqzIYWdTFBwKHvin3bowgS/8R+urd24meniHn5/xZOnlLBiNXs4LQLkm0nTqPz+A7GB64VFtGDREuro28Pw4p18e1L0ongqKLwh7N0rv08TJk75cEDwpPbu/0MsWFhUTOO+jTLNx8dHTqai4pvC/s979xs6HV1AfHv2YxvHAnU2G8UmrCBPL2/TQHDx9PKmJYlJZLO9FqfdtUc/c4D0Cgpmxw3DyDoDvxppOoCmMihkFJWW3WVr3r1XzvbQLCA+AX2EwWsFheTt3/uDg7A4BMnh0pV8tjZiEl7hFhD4J3enK/nXqL139xYDYXEI1sy/ViDcTC1mFIHwwIY7odi1NAiLQ6zdA4VXIAEYAoIUywO7JWJCT8zYHAkA2U0XEBQ7XieQnVobhMUh8cuTRPDLuZgESGLSWlEnzE6x/n0G0tYdu1m9qKyqYps6cPAwDRs9Vui0aWel8RFRFLt0OX3S/v36nl4+dONmCdsbQKkCAVJOO5SKHXSuXL1Ofx1Op886dtUNYn5MLL1+/Z6SOMu7d++Y/6/ZkEI3S26L/+FSzjZQ8RmdqXgi4WYuQEDeeIZQ2tDc6MVioYwTWYxHaYGYveAHseE/D6XRqDFfU5eAvtRv8DBKXLWOql+8kICrrKqivoNCXOzgtHgmnTE3WhkIWCyUwJ2UNpV58pTLglnZuazeKOljw69evWK6C2OXyuqg4IHe19bVudh++qxSogsbuJZzOk8eCFIsaDUYqRoBLC65xQzhZJCa8ftZZSXrL+T0k9ZuZDrHMk+qnppf7wGSU0nd86tsoUR/U19f77JPAQT0GjeDXqstyAsUAhTsNefMWbHw1esFNH3OAhd3O3P2PLsWOXmGpgum/rJP2EKfouS25y5cktgUQLb/+BO7iIBTW2zf7weYHp4091vEFgKQbwLdIFxl9fpkevjosWzgyklunv2hpB/LUG201m/awvS27dwtBYKFGUoFF+GC1Ai9qqrn5BcY5EIn0GzxFNlUwsZFaAK5nH+V6Y4In6Cq9900u/eczM6VAim7e49dRBenZgTkkW8O1AG1oalO0JDhLBulHc1gPA3uqEX6IOWOQhw4YIiq3oChI5ge5gISINXV9hQIbqNm5PadUpcnnbx5u+YG9QhctM5mYza1CCpYOPSeP6+WAkEmwEWtIvd3+jGmdyjtCEuFaqnXiHwZMpLZfVxRoamL+OFzAreBoOLzGJFzK3eFU6PfDhxsHhC9rgU5mnFC+OjQkeGmALl42d5ETZ01T1NX1bX0BjukndWPET4eJwhoPfcpCbIUT9teXfw19VWDHVRDT/rlAvrgHPSL4hPdBsLX3pCyVZc+T78nTuUoF0QMz/QY25W6h+ljwhi9ON6FchuRqOlzmJ3a2lpdbq1ZEPVSFC6gJ/cfPBSZBoXSKAgkC7gTbMTEJei+7/zFy+yeiKjpUiAgY5w0YpN6DKJw8X4agl4m7chxXXNcBCyn5Mczs3SDsPoFCtLYoWuAFIgz18EYU6/hnv0Hs6DjYLCIVhXHSfDCiqRhZLgRE5fA7svOPePyvwuQmfPsjRVmsXJGwidE0orV61kvj4oO5osnw0GU3LpNw8PHq24EwwMMrDkII7WoTTsrFd2wnyJYtiIQtLF8ETmf57XGWV7W1NDh9KMsk6gFfMioMZSZlS3uQyzqDW5Lk+kOYlK11YVgtA9lIG86fMBmHz2uEJtBTIFyox8PDg2jbr36MzBoeND1YeGUbTtd+vCamn/ZfNdolvP08hFNXdyylZLrEiA4FT7rxYJy4yKA5d2hXkHd2bR1h+FTsDR5wEgucslEdkDHpxUYiqk1RKFhY2nVumRWmBDwoAwYMMDdQMkRQ5u372KxpWdIYVEQnDafwChNdxRHphjP8Cfg7lM0Q3wC+gg6hFbYrSE2xkIwgMaoVYbYPv5sDsDnAWr1SfO1Aq8R6AzN6j30iNUvULS+iFmtFz66XvTwo4WbDR42+oODCA4NE2uClaPomvLqDU+DuxkSAGavSIdmA/D08mHZiQc23AkDPtNfhvIEAMG0xJ23r0oVGzWn2FEneGAbefdu+PU0KIZzUwXih97dna8YEAfgTpx2NDpcyZ23xW59MIDTgXs5D+VAFkGv1yVvYQwAXRzSNmYAEPzGS6NJ02YzHejyOQGnHXHLVrr9BUSzPuHAopiKY6AMumKk0tspTj0bDIIAtsonHBYZAb9Co4OuDRNAUBiQTP5RDX6DuoMFQAe6zv1Ec8XDLEOtLR6tvQGzgPwHJDItHeffHIEAAAAASUVORK5CYII=" style={{ width: '40px' }}/>
  </a>
        <a className="btn btn-outline-light btn-social" href="#" style={{ border: '1px solid #222A31' }}>
        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGPUlEQVR4nO2a+1dNaRjH+1vOuMxKpCtdqJgSEmbcB4UuohAxGoRmxhhDCKFGLiuLxbiWS4hcisY9QpTLDM2MdL8h1jPr++Td65zT2efsvc+p05rlh2et1j7P+7zvZ7/v+9x2DjpHF/o/iIO9F/AZxLGDdsTJ3YfCo2bT1oxMOnfhIj0pK6fqmhp69+4dC/5+XFZOZ8/nU1r6DgqLnMVjusSOfNHLlRefcyqXWlpa6OPHj6qkubmFsk+cZijY0tkDZNbcBCp5+Eha1Pv3rXT95i3atDWDZsbNp6AR35BLfz/q0ceDBX8PCR3Dv23elkE3bt7mMWL8/QcPKTouvvNAAoJD6XLBVWkBf718Rat+XU9e/kGqJ/cKGEI/r11PL19VSPbyLxeQX1BIx4LMTUik+vp6nvB1ZSUtXraS37a157unsyclJiXTmzdVbLuurp5i5y+yPQjOL46MeGuHjmbzUbEWwFhcvfzpaPYJaZ6NW7bZDgQQe/buZ8Nv376lRUuW2xzAWBKTktnTYc5dWftsAyJ2oqGxkcIiYjocQvdJ4A0bm5oU74yDpTshdsIWEP5DRrCrhd05CxbT7HkLaeqMGAodO4k8fAebhBE7Exu/UBsIvJO42NYcJ9yllNQ0A88kJyFfTzB5zPBbbW2dWW8mCyJcLC62VohR4yZTRcXf0kL/+fc15V+6whcagkBaeK2ImpqaZUF0ji6SA8BYVSAIdsLFavVOgcNHU0NDA9u5WnSdxkwKl9VFMDQH4urtL7nmyNnzlIHAS4mIjTihBQI2iu+VsI1jOSepe293s/qWQHSOLrRkxY+sc+9+icl0xsHUBRMRW2uwwwUWNpzcvNv97uYTQBOmRtDk6dEsz1/8aRGkp7Mnvapou2emHE87EJxbKCN10Ho3fj9yTNbGmpRU2QQzxAwI5Jd1G1nveM4p8yC9PXw4I0UypyV3ElL+9BlPOHz0eIPnSDvwHC618Nof/NL0ZWDgcLN2fQYFU2trKzuHXq5e8iDiWCGL1QqB4/jhwwdebPfebga/3S2+z/aTkldptn/rzl22geMrC4KiCEqI5loncvcdxDYqK98YPP+ybz8J0JqCKi19B9vfsv03eRBUdlBCzaB1IgQt2MAF1n/uHRDMzxFXtNrW6YWGM3kX5EHKyp+yEgoga9IQ2Hj2/EW7uILnKHetAQkeOdakHQOQqupqVkI63VVB3HwC2A4CpCwIkkMowWcrMRoVG89NBX1BTmQOBB7ReIyQ0eOnWJwTdw124MJlQUSmqTQQIiOVSwDlQMyJq7flk4CXLDJyWRC8FSj17TdQFUju2TzOyfTFud8AA124YmMd0ZAwdVR0MoJjD/2qqmp5EPSioIQLpQYk+2Su5jM/KTySbRRdv6lIf+iotste+viJPEjeJ/ertC1jC5ClK39iG/sPHlakj9AAfTT6ZEHQbzIVbCyBIFtevXaDgXy//AfDI+Ht304HgnoENlatSVE057aMnW1BOy1dHmT6zDhWunHrTqdf9oiYOYrmFCmKcQZsAIKUGwU/Ugk0zywZHTZqHKc1+rJ3/0GzILikxmMg/f0CLc6H7ABrQyPEbNIIOXH6jFX5VkcGxE2fOjqm7mQ7kCkzZkrFvrELtSdIH09fqqmtZRvwdBZBUEY+fFSq6gJ2BsjqtRvaSt2SB8qbDyjwxa4M+GqY3UG8A4KlYI2aSTEI5ErhNR4I99jNyc1uIN2c3Lia5HbQ5QJZPVkQlJ2iQYdttRfImpRU6XSg1FUNAkGEh7uDIAJ3Nsh3S1dwjY75NbdMhaSmbecFwGBCYlKngSQuS2YAjNmweattvo/s3LNXgkHwMpfmWwvSo48H1+UCIj1zt22/WOGeCON3iu9xk9vWIH5BIdzBgR7mUrITqkEgMXMWSEEJvaXM3VntUgstIOih7diVJX0PgatV2wBR/TEUcUWk+wIIX7TQAkWPVw0IuvVZ+w4YdB7PXbhIvoOHqlqTJhD9TBlHTD+DRfPifP4lsyDodx06cpz7wvpjb98tpmnRsZrWYhWIkIlhEXT4WI4Uc9Sk8fjsgO8v2M0u8y8cPZ096dtpUbRu4xau4Y2j8KChI6n0SRmdzD3LOhPDIhV3a3SdCWJvcbD3Aj6DOBruyH98ju45kkMdAgAAAABJRU5ErkJggg==" style={{ width: '40px' }}/>
      </a>
    <a className="btn btn-outline-light btn-social" href="#" style={{ border: '1px solid #222A31' }}>
    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAE80lEQVR4nO1Z+VMUVxDmb5lkk3J1VZZFQFEuARGVo8CDQ0AOQTAREjEGomiBgWQtJaJI8MALjcHERI2KIqKIWmqigCJymaoEFGQhwHJTneoOM+UC+9jdWRzK7A9dNbXT73V/3a/7fdtjxcmt4X0QK6kdsACRWzJiLfnx4Sw1Ipc+0pwlI/L3OCMfzbYFj2X+EL3hU0jdkQHZ+w/C6bPn4EpxCZRX3IMnldXQ2PQSWtvaQNPRQaLV9sLIyIgg3d3dwrvmllfQ0NhE6+7cvQ/FJaVQeLYI9ubkQkpaOtnxWxUKDi6eIFOoxAFZ5O4N+3Lz4VlNLQwMDOg49S6lr68Pfrt6jYAZDSQ5ZTt09/TobNjy6jVFv+jnX2B/3iFIy8iChKRkCI2MJSPu3n7g4OwB1vZOJDOVDjp7zrFbKLyzd3KHxd5+tA7Xx2/aDNt27qJMn/nxJygpLYP6hkadAA4ODkJ6ptpwIJjWoaEhWoxpD4veQMalOPcyhQr8V4fSEUZ/hoeHITp+0+RAZAob+OvvZlqUd7gAPpiplLyIuVHJP3qc/Kqsejo5EG+/VaT8urXV4CJ7V6KwXSA0EEc3LzaQuE8+I8Wbt8old5ybQDAb6F9YVBwbSEbWblI8fuqM5E5zE8ivFy+Tf9vTM9lACk4UkiKrO7Dk9p274OUbOGVAvjuQR/4dmyDQOkCu3bhJijEJiSYZwrXYMjEgSgdnswNJTP6SbGDAmEAePvqDFAOCwk0Gwku7RkNHAFmBuYD4rw6lvWtf1LGBVD+rIUXsXmKAFF+/ITzX1tVDeEy8WYA4ey6nPdva3rCBIF9CRVcvH1FA8Dk4IgZqntcKv5WW3Sa+JgaIraPb6C0/NO6O0wGCNAQVkWqIBYLy4SwbSPoilcgkTzMKfygClaOrSfvPsLYTbOCzXiCdnf+QEvIicwDhZa7dIsjNP0IEEN8jA85U74WP58wz2kZ/fz/tMXueo34gPEkztUD1AeEFiSUeMTH1096uobV4zCQD4rbUF66Xlgl6yHAjYzcaZaOrq2vyjHR0dpKSqWx3qo+WTKEiBjxpsTc3t5Ch+S5LpmWx2yxwEe6ose90gGCqURHPslggQeHR8LTmufAb3sZLfMTRF1cvH9qr6eWfbCBV1f+xS5/A4Gl5IfquDNH7n0QHyP0Hj0gRL7PpSFHCouKEf65MIJeuFJPiltQ0k4GIrQOOIVu/2kk2zp2/wAZy4PvDpIjDBVMMmYOGcAzBzof+4diICQQzwfOiqXJGjFwaPTFJW1LYQNaERZEi3ifYOqV2nBsjfDMKDI5gA8FzzY+CsENI7Tj3lsiV9tCj1ZJ/eJ8wgaBgv0cgt8orzNpxzDUOKq+4N+H7cUCWB6wRxi6PK6tgXexGk1iqOUSmUNE0kr+Xenv79I5OrfT1a55W8C21rr6BZrAH84/Cjl3fQELiZlgZEgGeKwJg4eKlxM8MrSt0UDnfGZw8lsGKwCAIWbeeCvhr9R44cuwkTRbxIuUpO91L7Rqagho9xMZ6ydqdTVnBSBg6dMYzzE/dxwrPXA0VrbaX7H+7Z9842m4wkLcFI43RWxsZB59v3Qbq7BwoOHkaLl6+SjX1++Mn8KK+gT4X8E7jZwTWZwXUx3W4HvfB/dTZObQ/2kF7xnROy3d2bhp0Ms6SEbn0kecsGZFLH23OkhG59BHm/q8Z+RfT0a+rgo5QvAAAAABJRU5ErkJggg==" style={{ width: '40px' }}/>
  </a>
  <a className="btn btn-outline-light btn-social" href="#" style={{ border: '1px solid #222A31' }}>
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAF/ElEQVR4nN1a608UVxTnb1lLH8iqLAvIQ8RHra2kD6tto21REUQRRWxVMCpSsEKq1VYERJS22ti0TZv0W2soEkp5iry0rbx8gRrRLwU2wOY0v8PcycLMzs4sO7ubfjjZnbl37r2/uefxO+dOiCUsgv4PEhLoBQQdEFtsEqXv3EMVVdVUU1tHt3v76OmzZ+RwOFjw/5/ePm5Dn7TMbIpYvDQ4gLwUEUM5+w9SXX0DTU5OktPpNCQTE5N0rf4P2rMvj15cFON/IGG2xVRUfIKGHz6SFzU+Pk4NjU104nQp78yq5LX8xp9fEMWC/7iHtpNfnOW+eEY8PzT8kAqPf8Yvxy9AtmRk0eCdu/ICbnR20YFDR2lhzBLDky+KSaTcQwXU0dktjzcweIc2pWeaBwRv6vKV7+UJO7t66MPU7T7T8ZS0HdTVc1Me/+vLVwztji4gMYkreeGY4N/RUTpSeJxCrZE+AyEk1BpJR4+V0OjomLzb0UtW+gbI0lXJvN0YGF5n9RvrfQ5gtrz25jvU29fPc/YPDPIa5gTEnrBcHrC9o5Mi45eZDsIiCZxDc2sbzw2bhFZ4BQT6KdSpta2dwiPj/AbCIgnmbGvvkNVMy2bcAhGGDXVCsPM3CIsktrgkWSvgAAwBgYsVhq1mEy8sjKbyyoscR+D/z56r4ntm2syo5ADg3XQBQbATcQLeSe2hssoLiihdWnHe1J0p+LRENn41FVMAOVZyUo4T7lwsdgF91m3YROs3bpYjs5lAQq126r55i+cCKE0gQCpoh1awE0AAQgYyNGwqEEtYBEd8MddsbjYDCMib8BBaA8ImZqvWmfJK04HMm2+TPenuj3LdAwGLRSdwJ60BYdgAg53B2wEIM43d4iJ5Rz7hNdbW1asDgYsFrQYj9YYA+jNQOhwOmpiYmLFOGQjoNZCCXnsarKXtukK1mlraNNsRpd/ekEI//vwLx4WxsXG2x99qailr7356Llw/d2tobOYx03bsVgI5d+ErbkQ+4Wkgd4mSp3YtAZVfqoNTQU6dKeNnKs5fVAJBCsooM7N1A9F7PTU1JXOm3MMFFLdsNSdb+EU+IuLWo8ePKfHlNR7n35Y1rT1Xf7+mBNLXP8CNyOJ8DaSq+hJ998NPZI2KVx0v3B7PxuuUPKYnNXvl9XXcF3UBBZCRkafcCG7jayCCMZwuLeeUAMaKX6gI7qMdIAelndmZs09zfrBw9HvyZEQJBIOjUY8bNQoEixWUXM0JCMqRe7iA7/16tUZzfgRDUSfwKxDsBK7v3rtPGzenMz1/f8s2unf/Ad9HMQL9Ela8qovuaAIxU7VEhgkQruN8kJrB92GfuA61RvI14pnXqmWmsWNharuN69kLd6rYlyFjN9P9ai3OSF+LJBlZOdwHwdRtQBT6GsxATmkFRCMUJdBA/mxq4T6pGVlKICBjgjSiAhisQGyxSTJpXBCdoAQCQUEZg4A2BCuQg/mF3A6bdr0/A0j2x3kygQtGIPPm26irezqx2rX3gHsgCDRIlNAxZav7VFctQqstxl27kbEsLgKbQNuDoSHtVBeC0j46A7m74gNyj9kTNza36m43MpbFpfjQc+svbs8vKla0K4CA94hIjIKylor5UwqlF4ykTO1QKESrWoGiGIpjgQaRvPY9zii1qjtuS6YoT4o3oId/mSX2hOVclMNaqr/51rsiNpIcDIBCckCK2PZ4un5juoiNX61zRo/HCiBm4lgB1/4CYYtNkosYsFlPBz66DnrE1kLN1rz1rl9sol+aE6xcTx6v6+gNb0OoGRwAaq9wh74GEGq1s3cShg11ikpY4fvDUOEAICgoe3P66i5i4yijR4oTwrCNnL0bPp7G+YTYdghqsShjevMVA+wA3EnQDqekSt6cFnv1wQB2B+ol6AwEjBT0+vMvy7juhCwObhtZIAT/cWiEpAh90FfUCQTtyC8q9voLiDl9woFJURVHTUqks0YEVBwsFgQwIJ9wWFQEBeWt23dx1oYKIM4eUdAQH9Xg/9+3ezk9RR/0dc0n5iohvhoo0BIS6AX4Csh/mP2dF9oTwNkAAAAASUVORK5CYII=" style={{ width: '40px' }}></img>
</a>
        </div>
      </div>
      
            <div className="col-lg-3 col-md-6">
              <h4 className="text-white mb-3">Gallery</h4>
              <div className="row g-2 pt-2">
                <div className="col-4">
                  <img className="img-fluid bg-light p-1" src={Course1} alt="" />
                </div>
                <div className="col-4">
                  <img className="img-fluid bg-light p-1" src={Course2} alt="" />
                </div>
                <div className="col-4">
                  <img className="img-fluid bg-light p-1" src={Course3} alt="" />
                </div>
                <div className="col-4">
                  <img className="img-fluid bg-light p-1" src={Course2} alt="" />
                </div>
                <div className="col-4">
                  <img className="img-fluid bg-light p-1" src={Course3} alt="" />
                </div>
                <div className="col-4">
                  <img className="img-fluid bg-light p-1" src={Course1} alt="" />
                </div>
              </div>
            </div>
            <div className="col-lg-3 col-md-6">
              <h4 className="text-white mb-3">Newsletter</h4>
              <p>Dolor amet sit justo amet elitr clita ipsum elitr est.</p>
              <div class="custom-container">
  <input class="custom-input" type="text" placeholder="Your email"/>
  
  <button type="button" class="custom-button ">
    SignUp
  </button>
</div>

            </div>
          </div>
        </div>
        <div className="container">
          <div className="copyright">
            <div className="row">
            <div className="col-md-6 text-center text-md-start mb-3 mb-md-0 text-white">
  © <a className="border-bottom text-white text-decoration-none" href="#">Your Site Name</a>, All Right Reserved.
  Designed By <a className="border-bottom text-white text-decoration-none" href="https://htmlcodex.com">HTML Codex</a><br /><br />
  Distributed By <a className="border-bottom text-white text-decoration-none" href="https://themewagon.com">ThemeWagon</a>
</div>

          
              <div className="col-md-6 text-center text-md-end">
              <div class="footer-menu text-white">
              <a href="#" class="text-white">Home</a><span class="mx-2">|</span>
              <a href="#" class="text-white">Cookies</a><span class="mx-2">|</span>
              <a href="#" class="text-white">Help</a><span class="mx-2">|</span>
              <a href="#" class="text-white">FAQs</a>
            </div>
            
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Main8;
