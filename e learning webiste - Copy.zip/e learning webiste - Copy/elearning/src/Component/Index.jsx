import React from 'react';
import Booksvg from "../assets/book.png";
import Main from './Main';
import Main2 from './Main2';
import Main3 from './Main3';
import Main4 from './Main4';
import Main5 from './Main5';
import Main6 from './Main6';
import Main7 from './Main7';
import Main8 from './Main8';
import 'bootstrap/dist/css/bootstrap.min.css';

function Index() {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-light bg-white">
        <div className="container-fluid">
          <a href="index.html" className="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 className="m-0 text-primary"><img src={Booksvg} alt="Book icon" />eLEARNING</h2>
          </a>

          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <ul className="navbar-nav mr-auto">
              <li className="nav-item active mr-3">
                <a className="nav-link fw-bold" href="#">
                  HOME
                </a>
              </li>
              <li className="nav-item mr-3">
                <a className="nav-link fw-bold" href="#">
                  ABOUT
                </a>
              </li>
              <li className="nav-item mr-3">
                <a className="nav-link fw-bold" href="#">
                  COURSES
                </a>
              </li>
              <li className="nav-item custom-select-container mr-3">
                <select className="custom-select bg-white border-0 mt-2 fw-bold">
                  <option value="pages" className="fw-bold">PAGES</option>
                  <option value="our team" className="fw-bold">Our Team</option>
                  <option value="Testimonial" className="fw-bold">Testimonial</option>
                  <option value="404 page" className="fw-bold">404 page</option>
                </select>
              </li>
              <li className="nav-item">
                <a className="nav-link fw-bold" href="#">
                  CONTACT
                </a>
              </li>
            </ul>

            <button className="btn btn-primary btn-lg ml-2" type="submit">
              Join Now &#8594;
            </button>
          </div>
        </div>
      </nav>

      {/* Use container-fluid for responsiveness */}
      <div className="container-fluid">
        <div className="row">
          {/* Use Bootstrap grid system for better layout */}
          <div className="col-lg-12">
            <Main />
          </div>
          <div className="col-lg-12">
            <Main2 />
          </div>
          <div className="col-lg-12">
            <Main3 />
          </div>
          <div className="col-lg-12">
            <Main4 />
          </div>
          <div className="col-lg-12">
            <Main5 />
          </div>
          <div className="col-lg-12">
            <Main6 />
          </div>
          <div className="col-lg-12">
            <Main7 />
          </div>
          <div className="col-lg-12">
            <Main8 />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Index;
