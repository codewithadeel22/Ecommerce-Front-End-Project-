import React from 'react';
import Course1 from "../assets/course-1.jpg";
import Course2 from "../assets/course-2.jpg";
import Course3 from "../assets/course-3.jpg";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowRight, faStar, faUserTie, faClock, faUser } from '@fortawesome/free-solid-svg-icons';

function Main5() {
  return (
    <div>
      <div className="container-xxl py-5">
        <div className="container">
          <div
            className="text-center wow fadeInUp"
            data-wow-delay="0.1s"
            style={{
              visibility: 'visible',
              animationDelay: '0.1s',
              animationName: 'fadeInUp'
            }}
          >
          <h6 className="section-title bg-white text-center text-primary px-3 with-lines">
          <h6 className="section-title bg-white text-center text-primary px-3 with-line"></h6>
          Courses
          
        </h6>
            <h1 className="mb-5">Popular Courses</h1>
          </div>
          <div className="row g-4 justify-content-center">
            <div
              className="col-lg-4 col-md-6 wow fadeInUp"
              data-wow-delay="0.1s"
              style={{
                visibility: 'visible',
                animationDelay: '0.1s',
                animationName: 'fadeInUp'
              }}
            >
              <div className="course-item bg-light">
                <div className="position-relative overflow-hidden">
                  <img className="img-fluid" src={Course1} alt="" />
                  <div className="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                    <a
                      href="#"
                      className="flex-shrink-0 btn btn-sm btn-primary px-3 border-end"
                      style={{ borderRadius: '30px 0 0 30px' }}
                    >
                      Read More
                    </a>
                    <a
                      href="#"
                      className="flex-shrink-0 btn btn-sm btn-primary px-3"
                      style={{ borderRadius: '0 30px 30px 0' }}
                    >
                      Join Now
                    </a>
                  </div>
                </div>
                <div className="text-center p-4 pb-0">
                  <h3 className="mb-0">$149.00</h3>
                  <div className="mb-3">
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <small>(123)</small>
                  </div>
                  <h5 className="mb-4">Web Design &amp; Development Course for Beginners</h5>
                </div>
                <div className="d-flex border-top">
                  <small className="flex-fill text-center border-end py-2">
                    <FontAwesomeIcon icon={faUserTie} className="me-2" />John Doe
                  </small>
                  <small className="flex-fill text-center border-end py-2">
                    <FontAwesomeIcon icon={faClock} className="text-primary me-2" />1.49 Hrs
                  </small>
                  <small className="flex-fill text-center py-2">
                    <FontAwesomeIcon icon={faUser} className="text-primary me-2" />30 Students
                  </small>
                </div>
              </div>
            </div>
            <div
              className="col-lg-4 col-md-6 wow fadeInUp"
              data-wow-delay="0.3s"
              style={{
                visibility: 'visible',
                animationDelay: '0.3s',
                animationName: 'fadeInUp'
              }}
            >
              <div className="course-item bg-light">
                <div className="position-relative overflow-hidden">
                  <img className="img-fluid" src={Course2} alt="" />
                  <div className="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                    <a
                      href="#"
                      className="flex-shrink-0 btn btn-sm btn-primary px-3 border-end"
                      style={{ borderRadius: '30px 0 0 30px' }}
                    >
                      Read More
                    </a>
                    <a
                      href="#"
                      className="flex-shrink-0 btn btn-sm btn-primary px-3"
                      style={{ borderRadius: '0 30px 30px 0' }}
                    >
                      Join Now
                    </a>
                  </div>
                </div>
                <div className="text-center p-4 pb-0">
                  <h3 className="mb-0">$149.00</h3>
                  <div className="mb-3">
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <small>(123)</small>
                  </div>
                  <h5 className="mb-4">Web Design &amp; Development Course for Beginners</h5>
                </div>
                <div className="d-flex border-top">
                  <small className="flex-fill text-center border-end py-2">
                    <FontAwesomeIcon icon={faUserTie} className="me-2" />John Doe
                  </small>
                  <small className="flex-fill text-center border-end py-2">
                    <FontAwesomeIcon icon={faClock} className="text-primary me-2" />1.49 Hrs
                  </small>
                  <small className="flex-fill text-center py-2">
                    <FontAwesomeIcon icon={faUser} className="text-primary me-2" />30 Students
                  </small>
                </div>
              </div>
            </div>
            <div
              className="col-lg-4 col-md-6 wow fadeInUp"
              data-wow-delay="0.5s"
              style={{
                visibility: 'visible',
                animationDelay: '0.5s',
                animationName: 'fadeInUp'
              }}
            >
              <div className="course-item bg-light">
                <div className="position-relative overflow-hidden">
                  <img className="img-fluid" src={Course3} alt="" />
                  <div className="w-100 d-flex justify-content-center position-absolute bottom-0 start-0 mb-4">
                    <a
                      href="#"
                      className="flex-shrink-0 btn btn-sm btn-primary px-3 border-end"
                      style={{ borderRadius: '30px 0 0 30px' }}
                    >
                      Read More
                    </a>
                    <a
                      href="#"
                      className="flex-shrink-0 btn btn-sm btn-primary px-3"
                      style={{ borderRadius: '0 30px 30px 0' }}
                    >
                      Join Now
                    </a>
                  </div>
                </div>
                <div className="text-center p-4 pb-0">
                  <h3 className="mb-0">$149.00</h3>
                  <div className="mb-3">
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <FontAwesomeIcon icon={faStar} className="text-primary" />
                    <small>(123)</small>
                  </div>
                  <h5 className="mb-4">Web Design &amp; Development Course for Beginners</h5>
                </div>
                <div className="d-flex border-top">
                  <small className="flex-fill text-center border-end py-2">
                    <FontAwesomeIcon icon={faUserTie} className="me-2" />John Doe
                  </small>
                  <small className="flex-fill text-center border-end py-2">
                    <FontAwesomeIcon icon={faClock} className="text-primary me-2" />1.49 Hrs
                  </small>
                  <small className="flex-fill text-center py-2">
                    <FontAwesomeIcon icon={faUser} className="text-primary me-2" />30 Students
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Main5;
