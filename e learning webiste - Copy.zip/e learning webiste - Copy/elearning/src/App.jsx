import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Index from './Component/Index';

function App() {
  return (
    <div>
      <Index />
    </div>
  );
}

export default App;
